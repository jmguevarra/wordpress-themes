<?php 
/**
 * Main Function file for this theme
 * 
 * Author: Jaime Guevarra Jr
 */

define('THEME_URI', get_template_directory_uri());
define('THEME_VERSION', '1.0.0');


/** THEME asset scripts and styles  */
require_once('lib/enqueue-assets.php');